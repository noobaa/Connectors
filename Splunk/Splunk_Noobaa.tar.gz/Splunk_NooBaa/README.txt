Splunk Add-on for NooBaa version 3.0
Copyright (C) 2005-2015 Splunk Inc. All Rights Reserved.

The Splunk Add-on for NooBaa allows a Splunk Enterprise administrator to collect log data from generic NooBaa S3 buckets. This add-on provides modular inputs and CIM-compatible knowledge to use with other Splunk Enterprise apps, such as Splunk App for Enterprise Security and Splunk App for PCI Compliance.

For release notes, refer to the Release notes section:
http://docs.splunk.com/Documentation/AddOns/latest/AWS/Releasenotes
